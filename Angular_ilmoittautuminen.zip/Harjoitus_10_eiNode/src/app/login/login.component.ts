import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm;
  cred: any[] = [];

  // tslint:disable-next-line: no-shadowed-variable
  constructor(private FormBuilder: FormBuilder, private AuthService: AuthService) {
    this.loginForm = this.FormBuilder.group({ username: '', password: '' });
  }
  onSubmit(loginData) { // login

    if (loginData.username === this.cred[0].username && loginData.password === this.cred[0].password) {
      this.AuthService.login();

    } else {
      alert('Tapahtui Virhe');
    }

  }
  /*getData hakee tietokannasta tiedon. sub-kertoo mitä datalle tehdään.
   Eli tallennetaan cred-muuttujaan. Käytetään log-kirjautuun any-taulukko kertoo datan tyypin */
  ngOnInit() {
    this.AuthService.getData().subscribe((data: any[]) => { this.cred = data; });
  }

}
