import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private cred;
  loggedIn = false;
  credUrl: 'http://localhost:80/api'; // tähän API:n osoite.

  // tslint:disable-next-line: no-shadowed-variable
  constructor(private http: HttpClient, private router: Router) { }
  getData() {
    return this.http.get('http://localhost:80/api/user');
  }
  login() {
    if (this.loggedIn === false) {
      this.loggedIn = true;
      this.router.navigate(['/form']);
    }
  }
  logout(){
    this.loggedIn = false;
    this.router.navigate(['/login']);
    alert('Nytpä lähdit!');
  }

  }

