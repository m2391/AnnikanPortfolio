import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent} from './form/form.component';
import { LoginComponent} from './login/login.component';
import { ListComponent} from './list/list.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
  {path: 'form', component: FormComponent, canActivate: [AuthGuard]},
  {path: 'login', component: LoginComponent },
  {path: 'list', component: ListComponent, canActivate: [AuthGuard]},
  {path: '', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
