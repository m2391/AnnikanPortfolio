import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { isNull } from 'util';
import {Router} from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  signForm;

  constructor(private FormBuilder: FormBuilder, private router: Router) {
    this.signForm = this.FormBuilder.group({
      name: '',
      email: '',
      food: '',
      sauna: ''
    }
    );
  }
  onSubmit(data) {
    let ilmoittautumiset = JSON.parse(localStorage.getItem('ilmoittautumiset'));
    if (isNull(ilmoittautumiset)) {
      ilmoittautumiset = [data];
    } else {
      ilmoittautumiset.push(data); // saatu data pushataan ilmoittumisten joukkoon.
    }
    localStorage.setItem('ilmoittautumiset', JSON.stringify(ilmoittautumiset));
    alert('Kiitos kun ilmoittauduit');
    this.router.navigate(['/list']);

   }


  ngOnInit() {
  }

}
