import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// omat komponenttini
import { LisaaLintuComponent } from './components/lisaa-lintu/lisaa-lintu.component';
import { MuokkaaLintuComponent } from './components/muokkaa-lintu/muokkaa-lintu.component';
import { LintuListaComponent } from './components/lintu-lista/lintu-lista.component';

// Andularin materiaali
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialModule } from './material.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// Firebase yhteys
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { environment } from 'src/environments/environment';

// Angulararin CRUD
import { LinnutService } from './shared/linnut.service';

// Reaktiiviset lomakkeet käyttöön
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LisaaLintuComponent,
    MuokkaaLintuComponent,
    LintuListaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [LinnutService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
