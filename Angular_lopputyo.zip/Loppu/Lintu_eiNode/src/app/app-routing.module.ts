import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// tuomme sovelluksen componentit reititykseen.
import { LisaaLintuComponent } from './components/lisaa-lintu/lisaa-lintu.component';
import { LintuListaComponent } from './components/lintu-lista/lintu-lista.component';
import { MuokkaaLintuComponent } from './components/muokkaa-lintu/muokkaa-lintu.component';

// reitteihin lisäämme componentit ja polut, joilla componentteihin pääsee
const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'lisaa-lintu' }, // tyhjä osoite vie linnun lisäykseen
  { path: 'lisaa-lintu', component: LisaaLintuComponent },
  { path: 'muokkaa-lintu/:id', component: MuokkaaLintuComponent },
  { path: 'lintu-lista', component: LintuListaComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

