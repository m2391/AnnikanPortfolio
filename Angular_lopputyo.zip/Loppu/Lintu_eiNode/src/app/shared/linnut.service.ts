import { Injectable } from '@angular/core';
import { Lintu } from './lintu';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';

@Injectable({
  providedIn: 'root'
})
export class LinnutService {
  linnutRef: AngularFireList<any>;
  lintuRef: AngularFireObject<any>;

  constructor(private db: AngularFireDatabase) { }

  // Lisätään lintu tietokantaan
  LisaaLintu(lintu: Lintu) {
    this.linnutRef.push({
      lintu_nimi: lintu.lintu_nimi,
      isbn_10: lintu.isbn_10,
      author_name: lintu.author_name,
      publication_date: lintu.publication_date,
      binding_type: lintu.binding_type,
      in_stock: lintu.in_stock,
      languages: lintu.languages
    })
      .catch(error => {
        this.errorMgmt(error);
      });
  }

  // haetaan lintu tietokanannasta
  HaeLintu(id: string) {
    this.lintuRef = this.db.object('lintu-lista/' + id);
    return this.lintuRef;
  }

  // haetaan kaikki linnut tietokannasta
  HaeLintuLista() {
    this.linnutRef = this.db.list('lintu-lista');
    return this.linnutRef;
  }

  // päivitetään yksittäinen lintu
  PaivitaLintu(id, lintu: Lintu) {
    this.lintuRef.update({
      lintu_nimi: lintu.lintu_nimi,
      isbn_10: lintu.isbn_10,
      author_name: lintu.author_name,
      publication_date: lintu.publication_date,
      binding_type: lintu.binding_type,
      in_stock: lintu.in_stock,
      languages: lintu.languages
    })
      .catch(error => {
        this.errorMgmt(error);
      });
  }

  PoistaLintu(id: string) {
    this.lintuRef = this.db.object('lintu-lista/' + id);
    this.lintuRef.remove()
      .catch(error => {
        this.errorMgmt(error);
      });
  }

  private errorMgmt(error) {
    console.log(error);
  }

}
