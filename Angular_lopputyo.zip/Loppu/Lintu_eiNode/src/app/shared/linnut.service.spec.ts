import { TestBed } from '@angular/core/testing';

import { LinnutService } from './linnut.service';

describe('LinnutService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LinnutService = TestBed.get(LinnutService);
    expect(service).toBeTruthy();
  });
});
