import { Component } from '@angular/core';
import { Lintu } from './../../shared/lintu';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { LinnutService } from './../../shared/linnut.service';

@Component({
  selector: 'app-lintu-lista',
  templateUrl: './lintu-lista.component.html',
  styleUrls: ['./lintu-lista.component.css']
})
export class LintuListaComponent {

  dataSource: MatTableDataSource<Lintu>;
  paginator: MatPaginator;
  LintuData: any = [];
  displayedColumns: any[] = [
    '$key',
    'lintu_nimi',
    'author_name',
    'publication_date',
    'action'
  ];

  constructor(private lintuApi: LinnutService) {
    this.lintuApi.HaeLintuLista()
    .snapshotChanges().subscribe(linnut => {
      linnut.forEach(item => {
        const a = item.payload.toJSON();
        a['$key'] = item.key;
        this.LintuData.push(a as Lintu);
      });
      /* Haetaan data */
      this.dataSource = new MatTableDataSource(this.LintuData);
      /* Pagination */
      setTimeout(() => {
        this.dataSource.paginator = this.paginator;
      }, 0);
  });
}

// linnun poisto tietokannasta
deleteLintu(index: number, e) {
  if (window.confirm('Oletko varma?')) {
    const data = this.dataSource.data;
    data.splice((this.paginator.pageIndex * this.paginator.pageSize) + index, 1);
    this.dataSource.data = data;
    this.lintuApi.PoistaLintu(e.$key);
  }
}
}
