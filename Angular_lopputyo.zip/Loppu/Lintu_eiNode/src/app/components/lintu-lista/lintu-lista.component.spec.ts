import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LintuListaComponent } from './lintu-lista.component';

describe('LintuListaComponent', () => {
  let component: LintuListaComponent;
  let fixture: ComponentFixture<LintuListaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LintuListaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LintuListaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
