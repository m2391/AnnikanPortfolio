import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MuokkaaLintuComponent } from './muokkaa-lintu.component';

describe('MuokkaaLintuComponent', () => {
  let component: MuokkaaLintuComponent;
  let fixture: ComponentFixture<MuokkaaLintuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MuokkaaLintuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MuokkaaLintuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
