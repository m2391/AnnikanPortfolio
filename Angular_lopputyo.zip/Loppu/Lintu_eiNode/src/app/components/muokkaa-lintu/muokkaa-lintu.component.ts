import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material';
import { LinnutService } from './../../shared/linnut.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

export interface Language {
  name: string;
}

@Component({
  selector: 'app-muokkaa-lintu',
  templateUrl: './muokkaa-lintu.component.html',
  styleUrls: ['./muokkaa-lintu.component.css']
})
export class MuokkaaLintuComponent implements OnInit {
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  languageArray: Language[] = [];
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  selectedBindingType: string;
  editLintuForm: FormGroup;
  BindingType: any = ['Sarjatuontanto', 'Vuosilintu', 'Yrityslintu', 'Koevedos'];

  ngOnInit() {
    this.paivitaLintuForm();
  }

  constructor(
    public fb: FormBuilder,
    private location: Location,
    private linnutApi: LinnutService,
    private actRoute: ActivatedRoute,
    private router: Router
  ) {
    const id = this.actRoute.snapshot.paramMap.get('id');
    this.linnutApi.HaeLintu(id).valueChanges().subscribe(data => {
      this.languageArray = data.languages;
      this.editLintuForm.setValue(data);

    });
  }

  paivitaLintuForm() {
      this.editLintuForm = this.fb.group({
        lintu_nimi: ['', [Validators.required]],
        isbn_10: ['', [Validators.required]],
        author_name: ['', [Validators.required]],
        publication_date: ['', [Validators.required]],
        binding_type: ['', [Validators.required]],
        in_stock: ['Yes'],
        languages: ['']
      });
    }
    add(event: MatChipInputEvent): void {
      const input: any = event.input;
      const value: any = event.value;
      // Add language
      if ((value || '').trim() && this.languageArray.length < 5) {
        this.languageArray.push({name: value.trim()});
      }
      // Reset the input value
      if (input) {
        input.value = '';
      }
    }

    remove(language: any): void {
      const index = this.languageArray.indexOf(language);
      if (index >= 0) {
        this.languageArray.splice(index, 1);
      }
    }
    /* Get errors */
    public handleError = (controlName: string, errorName: string) => {
      return this.editLintuForm.controls[controlName].hasError(errorName);
    }

    formatDate(e) {
      const convertDate = new Date(e.target.value).toISOString().substring(0, 10);
      this.editLintuForm.get('publication_date').setValue(convertDate, {
        onlyself: true
      });
    }
    goBack() {
      this.location.back();
    }

    paivitaLintu() {
      const id = this.actRoute.snapshot.paramMap.get('id');
      if (window.confirm('Haluatko varmasti päivittää')) {
        this.linnutApi.PaivitaLintu(id, this.editLintuForm.value);
        this.router.navigate(['lintu-lista']);
      }
    }
  }
