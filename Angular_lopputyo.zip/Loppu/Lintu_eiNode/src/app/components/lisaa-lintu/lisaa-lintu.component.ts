import { Component, OnInit } from '@angular/core';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material';
import { LinnutService } from './../../shared/linnut.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

export interface Language {
  name: string;
}

@Component({
  selector: 'app-lisaa-lintu',
  templateUrl: './lisaa-lintu.component.html',
  styleUrls: ['./lisaa-lintu.component.css']
})
export class LisaaLintuComponent implements OnInit {
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  languageArray: Language[] = [];
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  selectedBindingType: string;
  lintuForm: FormGroup;
  BindingType: any = ['Sarjatuontanto', 'Vuosilintu', 'Yrityslintu', 'Koevedos', 'Numeroitu'];


  constructor(
    public fb: FormBuilder,
    private linnutApi: LinnutService
  ) { }

  ngOnInit() {
    this.linnutApi.HaeLintuLista();
    this.submitLinnutForm();
  }
  remove(language: Language): void {
    const index = this.languageArray.indexOf(language);
    if (index >= 0) {
      this.languageArray.splice(index, 1);
    }
  }
  // reaktiivinen lintu-lomake
  submitLinnutForm() {
    this.lintuForm = this.fb.group({
      lintu_nimi: ['', [Validators.required]],
      isbn_10: ['', [Validators.required]],
      author_name: ['', [Validators.required]],
      publication_date: ['', [Validators.required]],
      binding_type: ['', [Validators.required]],
      in_stock: ['Yes'],
      languages: [this.languageArray]
    });
  }
  // Virheen käsittely
  public handleError = (controlName: string, errorName: string) => {
    return this.lintuForm.controls[controlName].hasError(errorName);
  }
  // lisätään kielet eli värit
  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    // Add language
    if ((value || '').trim() && this.languageArray.length < 5) {
      this.languageArray.push({ name: value.trim() });
    }
    // Reset the input value
    if (input) {
      input.value = '';
    }
  }
   /* Date */
   formatDate(e) {
    const convertDate = new Date(e.target.value).toISOString().substring(0, 10);
    this.lintuForm.get('publication_date').setValue(convertDate, {
      onlyself: true
    });
  }

  // lomakkeen resetointi
  resetForm() {
    this.languageArray = [];
    this.lintuForm.reset();
    Object.keys(this.lintuForm.controls).forEach(key => {
      this.lintuForm.controls[key].setErrors(null);
    });
  }

 submitLintu() {
    if (this.lintuForm.valid) {
      this.linnutApi.LisaaLintu(this.lintuForm.value);
      this.resetForm();
    }
  }

}
